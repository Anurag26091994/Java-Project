package package3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import package1.Account;
import package2.Rbi;

public class Sbi implements Rbi {
	double currentbal;
	double updatebal;
	double deposit;
	int pin;
	Scanner sc = new Scanner(System.in);
	Account a = new Account();

	@Override
	public void createAccount() {
		try {
			Class.forName("com.mysql.jdbc.Driver");

			try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root",
					"root");) {
				System.out.println("enter customer acc details ");
				System.out.println("enter customer acc no ");
				int accno = sc.nextInt();

				System.out.println("enter customer name ");
				String name = sc.next();

				System.out.println("enter customer mob no ");
				String mobno = sc.next();

				System.out.println("enter customer aadhar no ");
				String adharno = sc.next();

				System.out.println("enter customer gender ");
				String gender = sc.next();

				System.out.println("enter customer age ");
				int age = sc.nextInt();

				System.out.println("you have to pay atleast 500 rs to open acc ");
				System.out.println("enter amount ");
				deposit = sc.nextDouble();
				while (deposit < 499) {
					System.out.println("enter amount greater than 499");
					deposit = sc.nextDouble();
				}
				double balance = deposit;

				PreparedStatement ps = connection.prepareStatement("insert into account values(?,?,?,?,?,?,?)");

				ps.setInt(1, accno);
				ps.setString(2, name);
				ps.setString(3, mobno);
				ps.setString(4, adharno);
				ps.setString(5, gender);
				ps.setInt(6, age);
				ps.setDouble(7, balance);
				ps.execute();
				System.out.println("u r acc created successfully");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		// TODO Auto-generated method stub

	}

	@Override
	public void displayAllDetails() {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
			try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root",
					"root");) {
				PreparedStatement ps = connection.prepareStatement("select * from account");
				java.sql.ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1));
					System.out.println(rs.getString(2));
					System.out.println(rs.getString(3));
					System.out.println(rs.getString(4));
					System.out.println(rs.getString(5));
					System.out.println(rs.getInt(6));
					System.out.println(rs.getDouble(7));
					System.out.println();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void depositeMoney() {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
			try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root",
					"root");) {
				System.out.println("plz enter acc no to deposit money ");
				pin = sc.nextInt();
				/*
				 * while(pin!=a.getAccNo()) { System.out.
				 * println("u enter wrong acc no plz enter correct one ");
				 * pin=sc.nextInt(); }
				 */
				PreparedStatement ps = connection.prepareStatement("select accno from account where accno=?");
				ps.setInt(1, pin);
				ResultSet rs = ps.executeQuery();
				rs.next();
				int accno1 = rs.getInt(1);
				rs.close();
				System.out.println("how many amount u want to deposit ");
				deposit = sc.nextDouble();
				PreparedStatement ps1 = connection.prepareStatement("select balance from account  where accno=?");
				ps1.setInt(1, accno1);
				ResultSet rs1 = ps1.executeQuery();
				if (rs1.next())
					currentbal = rs1.getDouble("balance");
				rs1.close();
				updatebal = deposit + currentbal;
				PreparedStatement ps2 = connection.prepareStatement("update account set balance=? where accno=?");
				ps2.setDouble(1, updatebal);
				ps2.setInt(2, accno1);
				ps2.execute();
				System.out.println("amount deposited succefully ");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void withdrawal() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root",
					"root");) {
				System.out.println("enter u r acc no to withdraw money ");
				pin = sc.nextInt();
				/*
				 * while(pin!=a.getAccNo()) {
				 * System.out.println("u enter wrong no ");
				 * System.out.println("plz enter correct acc no ");
				 * pin=sc.nextInt(); }
				 */
				PreparedStatement ps=connection.prepareStatement("select accno from account where accno=?");
				ps.setInt(1, pin);
				ResultSet resultSet = ps.executeQuery();
				resultSet.next();
				int accno = resultSet.getInt(1);
				resultSet.close();
				
				System.out.println("how many amount u want to withdraw ");
				deposit = sc.nextDouble();
				
				PreparedStatement ps1=connection.prepareStatement("select balance from account where accno=?");
				ps1.setInt(1, accno);
				ResultSet resultSet2 = ps1.executeQuery();
				if(resultSet2.next())
					currentbal=resultSet2.getDouble("balance");
				if (currentbal <= 500) {
					System.out.println("u can't withdraw money because of ensufficent bal");
				} else {
					updatebal = currentbal - deposit;
					System.out.println(updatebal);
					PreparedStatement ps2=connection.prepareStatement("update account set balance=? where accno=?");
					ps2.setDouble(1, updatebal);
					ps2.setInt(2, accno);
					ps2.execute();
					System.out.println("amount withdraw successfully");
				}

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void balanceCheck() {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			try(Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
				)
			{
				System.out.println("enter u r acc no to check u current bal");
				pin = sc.nextInt();
				PreparedStatement ps=connection.prepareStatement("select accno from account where accno=?");
				ps.setInt(1, pin);
				ResultSet resultSet = ps.executeQuery();
				resultSet.next();
				int accno = resultSet.getInt(1);
				PreparedStatement ps1=connection.prepareStatement("select balance from account where accno=?");
				ps1.setInt(1, accno);
				ResultSet resultSet2 = ps1.executeQuery();
				resultSet2.next();
				double deposit = resultSet2.getDouble(1);
				/*while (pin != a.getAccNo()) {
					System.out.println("u enter wrong acc no plz enter correct ");
					pin = sc.nextInt();
				}*/

				System.out.println("u r current balance " + deposit);
			}catch(SQLException e){
				e.printStackTrace();
			}
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		
	}

}
